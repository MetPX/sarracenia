pip
===

The tool for data assimilation and distribution between clusters.
Develop by Shared Services Canada, Government of Canada.


**0.0.1**


* Initial release


Michel Grenier <michel.grenier@ssc-spc.gc.ca>
Jun Hu <jun.hu@ssc-spc.gc.ca>
Peter Silva <peter.silva@ssc-spc.gc.ca>


