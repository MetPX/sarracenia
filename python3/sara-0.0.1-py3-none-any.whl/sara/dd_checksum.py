#!/usr/bin/python3

# ===================================
# checksum_n = checksum for flag n
# ===================================

def checksum_N( filepath, offset=0, length=0 ):
    from hashlib import md5
    filename = os.path.basename(filepath)
    return md5(bytes(filename,'utf-8')).hexdigest()

# selfie

try    : self.checksum = checksum_N
except : pass
